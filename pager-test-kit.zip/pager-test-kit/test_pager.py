#!/usr/bin/env python3
# Simple pager test for BrandweerRooster / FireServiceRota.
#
# This script logs in, lists the pagers linked to your account, and lets
# you send a test message to one of them. It does not touch anything else
# (no incidents, no schedule, no live notifications).

import sys
from getpass import getpass

try:
    from pyfireservicerota import FireServiceRota, InvalidAuthError
except ImportError:
    print()
    print("ERROR: the 'pyfireservicerota' package is not installed.")
    print("Run this first:  pip install pyfireservicerota")
    print()
    input("Press Enter to close...")
    sys.exit(1)


def ask(prompt, default=None):
    suffix = f" [{default}]" if default else ""
    value = input(f"{prompt}{suffix}: ").strip()
    return value or default


def main():
    print("=" * 60)
    print(" BrandweerRooster / FireServiceRota - Pager test")
    print("=" * 60)
    print()

    base_url = ask("Website (base_url)", "www.brandweerrooster.nl")
    email = ask("Login e-mail")
    password = getpass("Password (hidden while typing): ")

    if not email or not password:
        print("\nEmail and password are required.")
        input("Press Enter to close...")
        sys.exit(1)

    print("\nLogging in...")
    api = FireServiceRota(base_url=base_url, username=email, password=password)

    try:
        api.request_tokens()
    except InvalidAuthError:
        print("\nLogin failed: incorrect e-mail or password.")
        input("Press Enter to close...")
        sys.exit(1)
    except Exception as exc:
        print(f"\nLogin failed: {exc}")
        input("Press Enter to close...")
        sys.exit(1)

    print("Login OK.\n")

    print("Fetching pagers linked to this account...")
    try:
        pagers = api.get_pagers()
    except Exception as exc:
        print(f"Could not fetch pagers: {exc}")
        input("Press Enter to close...")
        sys.exit(1)

    if not pagers:
        print("No pagers are linked to this account.")
        input("Press Enter to close...")
        sys.exit(0)

    print(f"\nFound {len(pagers)} pager(s):\n")
    for i, pager in enumerate(pagers):
        print(
            f"  [{i}] id={pager.get('id')}  "
            f"serial={pager.get('serial_number')}  "
            f"type={pager.get('type')}  "
            f"state={pager.get('state')}  "
            f"battery={pager.get('battery_level')}%"
        )

    print()
    choice = ask("Which pager number do you want to test? (index in [])", "0")
    try:
        index = int(choice)
        pager = pagers[index]
    except (ValueError, IndexError):
        print("Invalid choice.")
        input("Press Enter to close...")
        sys.exit(1)

    pager_id = pager["id"]

    print()
    message = ask("Test message to send", "Test message from pyfireservicerota")

    print(f"\nSending message to pager {pager_id}...")
    try:
        result = api.send_pager_message(pager_id, message, confirmation=True)
    except Exception as exc:
        print(f"Failed to send message: {exc}")
        input("Press Enter to close...")
        sys.exit(1)

    if not result:
        print("The server did not return a result. The message may not have been sent.")
        input("Press Enter to close...")
        sys.exit(1)

    message_id = result["id"]
    print("Message sent.")
    print(f"  id: {message_id}")
    print(f"  state: {result.get('acknowledgment_state')}")
    print(f"  address: {result.get('address')}")

    print("\nChecking delivery status (you may need to wait a moment for the pager to receive it)...")
    input("Press Enter once the pager has beeped / received the message, to check its status...")

    try:
        status = api.get_pager_message_status(pager_id, message_id)
    except Exception as exc:
        print(f"Could not fetch delivery status: {exc}")
        input("Press Enter to close...")
        sys.exit(1)

    if status:
        print(f"\nDelivery status: {status.get('acknowledgment_state')}")
    else:
        print("\nNo delivery status returned.")

    print("\nDone. Please copy everything above and send it back.")
    input("Press Enter to close...")


if __name__ == "__main__":
    main()
