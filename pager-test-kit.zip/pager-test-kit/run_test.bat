@echo off
title Pager test
cd /d "%~dp0"

where py >nul 2>nul
if %errorlevel%==0 (
    set PYCMD=py
) else (
    where python >nul 2>nul
    if %errorlevel%==0 (
        set PYCMD=python
    ) else (
        echo.
        echo Python was not found on this computer.
        echo Please install it first from https://www.python.org/downloads/
        echo IMPORTANT: on the first install screen, tick the box
        echo "Add python.exe to PATH" before clicking Install Now.
        echo.
        echo Then run this file again.
        echo.
        pause
        exit /b 1
    )
)

echo Installing/updating the pyfireservicerota package...
%PYCMD% -m pip install --upgrade pyfireservicerota
if errorlevel 1 (
    echo.
    echo Failed to install pyfireservicerota. See the error above.
    pause
    exit /b 1
)

echo.
echo Starting the pager test...
echo.
%PYCMD% test_pager.py

pause
